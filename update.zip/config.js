window.PORTFOYUM_CONFIG = {
  // Uygulama sahibi bu adresi yalnızca bir kez kendi Worker adresiyle değiştirir.
  apiBase: "https://portfoyum-api.haydarcicek94.workers.dev"
};
