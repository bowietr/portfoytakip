# Changelog

## V1.21.0 — Global Terminal Tasarım Sistemi

- Varlık Araştır ekranındaki terminal tasarım dili tüm uygulamaya yayıldı.
- Genel Bakış, Portföy, İşlemler ve Ayarlar ekranları koyu terminal paletine geçirildi.
- Kartlar, tablolar, butonlar, formlar, grafik panelleri ve metrikler ortak terminal bileşen sistemine bağlandı.
- Sayısal verilerde monospace/tabular görünüm ve daha sıkı veri yoğunluğu uygulandı.
- Mevcut hesaplama, portföy, işlem ve veri akışı korunarak yalnızca arayüz katmanı yenilendi.
- Sürüm/cache V1.21.0 olarak senkronlandı.


## V1.20.7 — Geçmiş Sekmesi Düzeltmesi

- Geçmiş sekmesindeki `Fon Büyüklüğü`, `Fon Profili` ve `Ücret ve Giderler` kartları kaldırıldı.
- `Fon Büyüklüğü Geçmişi` grafiği Geçmiş sekmesine geri eklendi.
- `Yatırımcı Sayısı Geçmişi` grafiği Geçmiş sekmesine geri eklendi.
- Genel Bakış'taki AUM grafiği ve Portföy sekmesindeki diğer Fonoloji detayları korunuyor.
- Sürüm/cache V1.20.7 olarak senkronlandı.


## V1.20.6 — Geçmiş Sadeleştirmesi

- Geçmiş bölümündeki `Fon Büyüklüğü Geçmişi` grafiği kaldırıldı.
- Geçmiş bölümündeki `Yatırımcı Sayısı Geçmişi` grafiği kaldırıldı.
- Fonoloji verisinin diğer kullanımları korunarak yalnızca bu iki tekrar eden görsel bileşen temizlendi.
- Sürüm/cache V1.20.6 olarak senkronlandı.


## V1.20.5 — Tekrar Eden Alanlar

- Terminal navigasyonundaki gereksiz Risk sekmesi kaldırıldı.
- Fonoloji detaylarında Genel Bakış'taki veriyi tekrar eden ikinci Aylık Getiri Haritası kaldırıldı.
- Genel Bakış'taki ana aylık getiri görünümü korunuyor.
- Sürüm/cache V1.20.5 olarak senkronlandı.


## V1.20.4 — Araştırma Ekranı Sadeleştirmesi

- Boş ve tekrarlayan `Risk` sekmesi kaldırıldı.
- Genel görünümde tekrar eden `Aylık Getiri Haritası` kartı kaldırıldı.
- Portföy dağılımı bölümü korunarak kullanılabilir alan sadeleştirildi.
- Sürüm/cache V1.20.4 olarak senkronlandı.


## V1.20.3 — Fon Arama Hatası Düzeltmesi

- `Maximum call stack size exceeded` hatasına neden olan scroll helper özyinelemesi giderildi.
- `resetResearchScroll()` artık yalnızca gerçek scroll alanlarını sıfırlar ve kendini tekrar çağırmaz.
- Fon arama akışı ve araştırma ekranı yeniden çalışır hale getirildi.
- Sürüm ve cache değerleri V1.20.3 olarak senkronlandı.


## V1.20.2 — Araştırma Viewport Düzeltmesi

- Araştırma ekranının aşağı itilmesine neden olan eski document-scroll / sabit sidebar çakışması giderildi.
- Varlık Araştır açıkken ana içerik alanı viewport'a sabitlendi ve kendi scroll alanına dönüştürüldü.
- Araştırma ekranına her girişte hem içerik scroller'ı hem document scroll konumu sıfırlanır.
- Sürüm ve cache değerleri V1.20.2 olarak senkronlandı.


## V1.20.1 — Araştırma Yerleşim Düzeltmesi

- Varlık Araştır ekranına geçildiğinde scroll konumu otomatik olarak en üste sıfırlanır.
- Önceki ekrandan taşınan scroll konumunun oluşturduğu büyük üst boşluk giderildi.
- Yinelenen üst hızlı arama alanı kaldırıldı; yalnızca sağdaki fon türü + kod + Araştır formu bırakıldı.
- Görünen sürüm ve cache sürümleri V1.20.1 olarak senkronlandı.


## V1.19.0 — Reference-Matched Terminal UI

- Fon araştırma ekranı seçilen referans tasarıma göre baştan düzenlendi.
- Sol terminal menüsü, canlı veri başlığı, kompakt arama alanı ve fon bilgi kartı eklendi.
- Dönemsel getiri şeridi ve terminal sekmeleri referans hiyerarşisine taşındı.
- Ana görünümde çizgi performans grafiği, yoğun risk tablosu, aylık getiri matrisi ve AUM grafiği bir araya getirildi.
- Fonoloji / TEFAS veri akışı ve Worker altyapısı değiştirilmedi.


## V1.18.0 — Terminal UI Refinement

- Fon kimliği ve temel bilgiler üst terminal kartında birleştirildi.
- Tekrarlayan ayrı kimlik şeridi kaldırıldı.
- Fon performans grafiği kümülatif çizgi grafik olarak yenilendi.
- 1A / 3A / 6A / 1Y dönem seçimi eklendi.
- Risk metrikleri daha yoğun terminal tablosuna dönüştürüldü.
- Koyu tema, ikinci terminal tasarım hedefi doğrultusunda yeniden düzenlendi.


Portföyüm uygulamasındaki önemli değişiklikler burada tutulur.

## V1.17.0 — Portföyüm Terminal

- Fon araştırma ekranı profesyonel terminal tasarım diline geçirildi.
- Kompakt performans metrik şeridi ve Fon Kimliği bilgi şeridi eklendi.
- Genel Bakış, Performans, Risk, Portföy ve Geçmiş terminal sekmeleri eklendi.
- Veri yoğunluğu artırılırken mevcut Fonoloji/TEFAS veri akışı korunmuştur.

## V1.16.2 — Stable

- Fonoloji tabanlı fon araştırma altyapısının stabil temel sürümü.
