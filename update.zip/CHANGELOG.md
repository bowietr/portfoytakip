# Changelog

## V1.20.1 — Araştırma Yerleşim Düzeltmesi

- Varlık Araştır ekranına geçildiğinde scroll konumu otomatik olarak en üste sıfırlanır.
- Önceki ekrandan taşınan scroll konumunun oluşturduğu büyük üst boşluk giderildi.
- Yinelenen üst hızlı arama alanı kaldırıldı; yalnızca sağdaki fon türü + kod + Araştır formu bırakıldı.
- Görünen sürüm ve cache sürümleri V1.20.1 olarak senkronlandı.


## V1.19.0 — Reference-Matched Terminal UI

- Fon araştırma ekranı seçilen referans tasarıma göre baştan düzenlendi.
- Sol terminal menüsü, canlı veri başlığı, kompakt arama alanı ve fon bilgi kartı eklendi.
- Dönemsel getiri şeridi ve terminal sekmeleri referans hiyerarşisine taşındı.
- Ana görünümde çizgi performans grafiği, yoğun risk tablosu, aylık getiri matrisi ve AUM grafiği bir araya getirildi.
- Fonoloji / TEFAS veri akışı ve Worker altyapısı değiştirilmedi.


## V1.18.0 — Terminal UI Refinement

- Fon kimliği ve temel bilgiler üst terminal kartında birleştirildi.
- Tekrarlayan ayrı kimlik şeridi kaldırıldı.
- Fon performans grafiği kümülatif çizgi grafik olarak yenilendi.
- 1A / 3A / 6A / 1Y dönem seçimi eklendi.
- Risk metrikleri daha yoğun terminal tablosuna dönüştürüldü.
- Koyu tema, ikinci terminal tasarım hedefi doğrultusunda yeniden düzenlendi.


Portföyüm uygulamasındaki önemli değişiklikler burada tutulur.

## V1.17.0 — Portföyüm Terminal

- Fon araştırma ekranı profesyonel terminal tasarım diline geçirildi.
- Kompakt performans metrik şeridi ve Fon Kimliği bilgi şeridi eklendi.
- Genel Bakış, Performans, Risk, Portföy ve Geçmiş terminal sekmeleri eklendi.
- Veri yoğunluğu artırılırken mevcut Fonoloji/TEFAS veri akışı korunmuştur.

## V1.16.2 — Stable

- Fonoloji tabanlı fon araştırma altyapısının stabil temel sürümü.
