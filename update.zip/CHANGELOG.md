# Changelog

Portföyüm uygulamasındaki önemli değişiklikler burada tutulur.

## V1.17.0 — Portföyüm Terminal

- Fon araştırma ekranı profesyonel terminal tasarım diline geçirildi.
- Kompakt performans metrik şeridi ve Fon Kimliği bilgi şeridi eklendi.
- Genel Bakış, Performans, Risk, Portföy ve Geçmiş terminal sekmeleri eklendi.
- Veri yoğunluğu artırılırken mevcut Fonoloji/TEFAS veri akışı korunmuştur.

## V1.16.2 — Stable

- Fonoloji tabanlı fon araştırma altyapısının stabil temel sürümü.
