# Changelog

## V1.23.2 — Cloudflare Deploy Tarih Düzeltmesi

- Cloudflare build hatasına neden olan `compatibility_date = "2026-08-17"` değeri `2026-08-16` olarak düzeltildi.
- GitHub → Cloudflare otomatik Worker deploy akışı için mevcut Wrangler yapılandırması korunur.
- Rate limit binding ve diğer Worker ayarları değiştirilmedi.
- Sürüm/cache V1.23.2 olarak güncellendi.


## V1.23.1 — Merkezi Worker Bağlantısı

- Production Worker adresi `config.js` içine tanımlandı.
- Son kullanıcı artık Worker adresi veya API anahtarı girmeden uygulamayı kullanabilir.
- Merkezi backend: `portfoyum-api.haydarcicek94.workers.dev`
- Sürüm/cache V1.23.1 olarak güncellendi.


## V1.23.0 — Ortak Production Backend

- Son kullanıcıdan Worker URL isteme kaldırıldı; API adresi `config.js` üzerinden tek seferlik uygulama sahibi ayarına taşındı.
- Ayarlar ekranındaki Worker URL ve bağlantı testi kaldırıldı.
- Tarayıcıya anonim kalıcı client ID ve `X-Portfoyum-Client` başlığı eklendi.
- Worker'a yüksek trafikli araştırma endpoint'leri için response cache eklendi.
- Fonoloji cache yapısına stale fallback eklendi.
- Cloudflare Rate Limiting binding ve opsiyonel `ALLOWED_ORIGINS` desteği eklendi.
- `FONOLOJI_KEY` required secret olarak tanımlandı.
- Sürüm/cache V1.23.0 olarak güncellendi.


## V1.22.4 — Uygulama İkonu

- Seçilen Portföyüm Terminal ikonu uygulamanın gerçek favicon / app icon setine eklendi.
- 32, 48, 180, 192 ve 512 px ikon varyantları oluşturuldu.
- Safari / iOS için Apple Touch Icon eklendi.
- Favicon ve web manifest bağlantıları index.html'e tanımlandı.
- Uygulamanın işlevsel koduna dokunulmadı.
- Sürüm/cache V1.22.4 olarak güncellendi.


## V1.22.3 — Mobil Alt Menü Düzeltmesi

- Mobil/tablet alt navigasyon tekrar görünür hale getirildi.
- 900 px ve altındaki ekranlarda sidebar zorunlu olarak sabit alt bar olarak gösterilir.
- Eski research/sidebar kurallarının alt menüyü gizlemesi `display`, `visibility`, `opacity` ve `z-index` seviyesinde engellendi.
- Menü içerik tarafından örtülmesin diye ana içerik alt boşluğu artırıldı.
- Masaüstü sol sidebar davranışı korunur.
- Sürüm/cache V1.22.3 olarak güncellendi.


## V1.22.2 — Geçmiş Grafiklerinin Kesin Sekme Düzeltmesi

- Asıl hata tespit edildi: eski `#researchSecondarySections { display:grid !important; }` kuralı, `hidden` durumunu CSS özgüllüğü nedeniyle eziyordu.
- Çakışan `display:grid !important` doğrudan eski kuraldan kaldırıldı.
- Geçmiş kapsayıcısı yalnızca görünür ve Geçmiş sekmesi aktif olduğunda `display:grid` alır.
- `Fon Büyüklüğü Geçmişi` ve `Yatırımcı Sayısı Geçmişi` artık Genel Bakış, Performans ve Portföy sekmelerinde CSS seviyesinde görünemez.
- Sürüm/cache V1.22.2 olarak güncellendi.


## V1.22.1 — Geçmiş Sekmesi İzolasyonu

- `Fon Büyüklüğü Geçmişi` ve `Yatırımcı Sayısı Geçmişi` yalnızca Geçmiş sekmesine bağlandı.
- History kapsayıcısı HTML'de varsayılan olarak `hidden` başlar.
- Sekme değişiminde hem `hidden` niteliği hem `terminal-tab-hidden` sınıfı yönetilir.
- Asenkron Fonoloji verisi yüklendiğinde aktif sekme yeniden kontrol edilir; grafikler diğer sekmelerde açılmaz.
- Sürüm/cache V1.22.1 olarak güncellendi.


## V1.22.0 — Genel Sekmesi Temizliği

- Genel sekmesinde görünen `Fon Büyüklüğü Geçmişi` ve `Yatırımcı Sayısı Geçmişi` blokları kaldırıldı.
- Bu iki grafik silinmedi; yalnızca `Geçmiş` sekmesinde gösterilmeye devam eder.
- Sekme görünürlüğü JS + CSS seviyesinde sıkılaştırıldı; asenkron veri yüklenince Genel sekmesine tekrar sızmaları engellendi.
- Sürüm/cache V1.22.0 olarak güncellendi.


## V1.21.9 — Tek Tema Modu

- Sidebar'daki Koyu / Açık tema seçici kaldırıldı.
- Ayarlar ekranındaki Tema kartı ve Tema Değiştir butonu kaldırıldı.
- Uygulama koyu terminal temasına sabitlendi.
- Önceden localStorage'a kaydedilmiş tema tercihi yüklemede temizlenir.
- API ve diğer kullanıcı ayarları korunur.
- Sürüm/cache V1.21.9 olarak senkronlandı.


## V1.21.8 — Sidebar Tek Kaynak Düzeltmesi

- Varlık Araştır'a özel logo, marka yazısı, menü ve sidebar-alt stilleri kaynak CSS'ten kaldırıldı.
- Genel Bakış ve Varlık Araştır artık aynı `.terminal-app-mode` sidebar/brand/nav stillerini birebir paylaşır.
- Araştırma modunda yalnızca sidebar konumu ve içerik scroll geometrisi ayrı tutulur; görsel ölçülere müdahale edilmez.
- Önceki sahte logo `::before`, farklı font-size, nav margin ve footer spacing kalıntıları temizlendi.
- Sürüm/cache V1.21.8 olarak senkronlandı.


## V1.21.7 — Varlık Araştır Sidebar/Logo Kesin Eşitleme

- Varlık Araştır'daki eski `nav margin-top: 28px` etkisi tamamen sıfırlandı.
- Araştırma ekranında logoyu değiştiren `font-size: 0` + sahte `::before P` yöntemi devre dışı bırakıldı.
- Logo kutusu, PORTFÖYÜM / TERMINAL tipografisi, menü satırları ve sidebar alt alanı Genel Bakış ile aynı ölçülere sabitlendi.
- Sidebar footer aralığı Genel Bakış'taki 10 px düzene getirildi.
- Araştırma içerik scroll sistemi korunurken sol navigasyon artık sekme değişiminde hareket etmez.
- Mobil sabit alt bar davranışı korunur.
- Sürüm/cache V1.21.7 olarak senkronlandı.


## V1.21.6 — Varlık Araştır Hizalama Düzeltmesi

- Varlık Araştır ekranındaki sidebar ve içerik başlangıcı Genel Bakış ile aynı 240 px koordinat sistemine sabitlendi.
- Eski 210/230 px research kurallarının masaüstü/tablet görünümünde yeniden devreye girmesi engellendi.
- Logo, menü satırları, tema alanı ve ana içerik yatay konumu sekme değişiminde artık kaymaz.
- Mobil alt bar davranışı V1.21.5'teki haliyle korundu.
- Sürüm/cache V1.21.6 olarak senkronlandı.


## V1.21.5 — Mobil / Tablet Navigasyon Düzeltmesi

- Varlık Araştır ekranındaki eski mobil `position: relative` sidebar kuralı final override ile etkisizleştirildi.
- Telefon ve tablette Varlık Araştır artık Genel Bakış ile aynı sabit alt navigasyonu kullanır.
- Mobil/tablet alt barda yalnızca 5 ana menü ikonu gösterilir.
- Logo, tema seçici, Fonoloji açıklaması ve sürüm bilgisi mobil sidebar içinde gizlenir.
- Masaüstü sol sidebar davranışı değiştirilmedi.
- Sürüm/cache V1.21.5 olarak senkronlandı.


## V1.21.4 — Geçmiş Grafik Gerçek Genişlik Düzeltmesi

- Grafiklerin küçük kalmasına neden olan dış `researchSecondarySections` iki sütunlu grid yapısı düzeltildi.
- Geçmiş sekmesinin dış kapsayıcısı artık tek tam genişlik sütun kullanır.
- Fon Büyüklüğü Geçmişi ve Yatırımcı Sayısı Geçmişi bu tam alanın içinde eşit %50 / %50 paylaşılır.
- Grafik yüksekliği 355 px'e çıkarıldı ve canvas kart genişliğine zorlandı.
- Dar ekranlarda tek sütun davranışı korunuyor.
- Sürüm/cache V1.21.4 olarak senkronlandı.


## V1.21.3 — Varlık Araştır Ölçek Düzeltmesi

- Varlık Araştır ekranındaki özel sidebar boyutlandırmaları kaldırılarak Genel Bakış ile aynı ölçülere getirildi.
- Logo, PORTFÖYÜM/TERMINAL yazıları, menü satırları, ikonlar ve sidebar genişliği sekmeler arasında artık değişmez.
- Araştırma ekranının scroll düzeltmesi korunurken içerik başlangıcı 240 px global sidebar ölçüsüne bağlandı.
- Tablet yatay görünümündeki 210 px özel araştırma sidebar kuralı kaldırıldı.
- Sürüm/cache V1.21.3 olarak senkronlandı.


## V1.21.2 — Terminal Renk Temizliği

- Eski tasarımdan kalan dekoratif yeşil/sage tonları uygulama genelinde temizlendi.
- Portföy filtreleri, günlük getiri şeritleri, varlık/pozisyon ikonları ve eski accent alanları terminal mavi-grafit paletine geçirildi.
- Genel Bakış varlık dağılımı grafiği mavi/cyan/mor terminal paletine geçirildi.
- Eski CSS değişkenleri koyu terminal sistemiyle senkronlandı; gözden kaçmış eski bileşenler de yeni paleti kullanır.
- Gerçek kazanç/kayıp anlamındaki yeşil ve kırmızı renkler semantik olarak korundu.
- Sürüm/cache V1.21.2 olarak senkronlandı.


## V1.21.1 — Geçmiş Grafik Yerleşimi

- Fon Büyüklüğü Geçmişi ve Yatırımcı Sayısı Geçmişi kartları mevcut alanı eşit şekilde dolduracak biçimde genişletildi.
- Grafik yüksekliği artırıldı; tarih ve eksen etiketlerinin sıkışması azaltıldı.
- Tablet/dar ekranlarda grafikler otomatik olarak tek sütuna geçecek şekilde düzenlendi.
- Sürüm/cache V1.21.1 olarak senkronlandı.


## V1.21.0 — Global Terminal Tasarım Sistemi

- Varlık Araştır ekranındaki terminal tasarım dili tüm uygulamaya yayıldı.
- Genel Bakış, Portföy, İşlemler ve Ayarlar ekranları koyu terminal paletine geçirildi.
- Kartlar, tablolar, butonlar, formlar, grafik panelleri ve metrikler ortak terminal bileşen sistemine bağlandı.
- Sayısal verilerde monospace/tabular görünüm ve daha sıkı veri yoğunluğu uygulandı.
- Mevcut hesaplama, portföy, işlem ve veri akışı korunarak yalnızca arayüz katmanı yenilendi.
- Sürüm/cache V1.21.0 olarak senkronlandı.


## V1.20.7 — Geçmiş Sekmesi Düzeltmesi

- Geçmiş sekmesindeki `Fon Büyüklüğü`, `Fon Profili` ve `Ücret ve Giderler` kartları kaldırıldı.
- `Fon Büyüklüğü Geçmişi` grafiği Geçmiş sekmesine geri eklendi.
- `Yatırımcı Sayısı Geçmişi` grafiği Geçmiş sekmesine geri eklendi.
- Genel Bakış'taki AUM grafiği ve Portföy sekmesindeki diğer Fonoloji detayları korunuyor.
- Sürüm/cache V1.20.7 olarak senkronlandı.


## V1.20.6 — Geçmiş Sadeleştirmesi

- Geçmiş bölümündeki `Fon Büyüklüğü Geçmişi` grafiği kaldırıldı.
- Geçmiş bölümündeki `Yatırımcı Sayısı Geçmişi` grafiği kaldırıldı.
- Fonoloji verisinin diğer kullanımları korunarak yalnızca bu iki tekrar eden görsel bileşen temizlendi.
- Sürüm/cache V1.20.6 olarak senkronlandı.


## V1.20.5 — Tekrar Eden Alanlar

- Terminal navigasyonundaki gereksiz Risk sekmesi kaldırıldı.
- Fonoloji detaylarında Genel Bakış'taki veriyi tekrar eden ikinci Aylık Getiri Haritası kaldırıldı.
- Genel Bakış'taki ana aylık getiri görünümü korunuyor.
- Sürüm/cache V1.20.5 olarak senkronlandı.


## V1.20.4 — Araştırma Ekranı Sadeleştirmesi

- Boş ve tekrarlayan `Risk` sekmesi kaldırıldı.
- Genel görünümde tekrar eden `Aylık Getiri Haritası` kartı kaldırıldı.
- Portföy dağılımı bölümü korunarak kullanılabilir alan sadeleştirildi.
- Sürüm/cache V1.20.4 olarak senkronlandı.


## V1.20.3 — Fon Arama Hatası Düzeltmesi

- `Maximum call stack size exceeded` hatasına neden olan scroll helper özyinelemesi giderildi.
- `resetResearchScroll()` artık yalnızca gerçek scroll alanlarını sıfırlar ve kendini tekrar çağırmaz.
- Fon arama akışı ve araştırma ekranı yeniden çalışır hale getirildi.
- Sürüm ve cache değerleri V1.20.3 olarak senkronlandı.


## V1.20.2 — Araştırma Viewport Düzeltmesi

- Araştırma ekranının aşağı itilmesine neden olan eski document-scroll / sabit sidebar çakışması giderildi.
- Varlık Araştır açıkken ana içerik alanı viewport'a sabitlendi ve kendi scroll alanına dönüştürüldü.
- Araştırma ekranına her girişte hem içerik scroller'ı hem document scroll konumu sıfırlanır.
- Sürüm ve cache değerleri V1.20.2 olarak senkronlandı.


## V1.20.1 — Araştırma Yerleşim Düzeltmesi

- Varlık Araştır ekranına geçildiğinde scroll konumu otomatik olarak en üste sıfırlanır.
- Önceki ekrandan taşınan scroll konumunun oluşturduğu büyük üst boşluk giderildi.
- Yinelenen üst hızlı arama alanı kaldırıldı; yalnızca sağdaki fon türü + kod + Araştır formu bırakıldı.
- Görünen sürüm ve cache sürümleri V1.20.1 olarak senkronlandı.


## V1.19.0 — Reference-Matched Terminal UI

- Fon araştırma ekranı seçilen referans tasarıma göre baştan düzenlendi.
- Sol terminal menüsü, canlı veri başlığı, kompakt arama alanı ve fon bilgi kartı eklendi.
- Dönemsel getiri şeridi ve terminal sekmeleri referans hiyerarşisine taşındı.
- Ana görünümde çizgi performans grafiği, yoğun risk tablosu, aylık getiri matrisi ve AUM grafiği bir araya getirildi.
- Fonoloji / TEFAS veri akışı ve Worker altyapısı değiştirilmedi.


## V1.18.0 — Terminal UI Refinement

- Fon kimliği ve temel bilgiler üst terminal kartında birleştirildi.
- Tekrarlayan ayrı kimlik şeridi kaldırıldı.
- Fon performans grafiği kümülatif çizgi grafik olarak yenilendi.
- 1A / 3A / 6A / 1Y dönem seçimi eklendi.
- Risk metrikleri daha yoğun terminal tablosuna dönüştürüldü.
- Koyu tema, ikinci terminal tasarım hedefi doğrultusunda yeniden düzenlendi.


Portföyüm uygulamasındaki önemli değişiklikler burada tutulur.

## V1.17.0 — Portföyüm Terminal

- Fon araştırma ekranı profesyonel terminal tasarım diline geçirildi.
- Kompakt performans metrik şeridi ve Fon Kimliği bilgi şeridi eklendi.
- Genel Bakış, Performans, Risk, Portföy ve Geçmiş terminal sekmeleri eklendi.
- Veri yoğunluğu artırılırken mevcut Fonoloji/TEFAS veri akışı korunmuştur.

## V1.16.2 — Stable

- Fonoloji tabanlı fon araştırma altyapısının stabil temel sürümü.
