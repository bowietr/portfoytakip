# Changelog

## V1.18.0 — Terminal UI Refinement

- Fon kimliği ve temel bilgiler üst terminal kartında birleştirildi.
- Tekrarlayan ayrı kimlik şeridi kaldırıldı.
- Fon performans grafiği kümülatif çizgi grafik olarak yenilendi.
- 1A / 3A / 6A / 1Y dönem seçimi eklendi.
- Risk metrikleri daha yoğun terminal tablosuna dönüştürüldü.
- Koyu tema, ikinci terminal tasarım hedefi doğrultusunda yeniden düzenlendi.


Portföyüm uygulamasındaki önemli değişiklikler burada tutulur.

## V1.17.0 — Portföyüm Terminal

- Fon araştırma ekranı profesyonel terminal tasarım diline geçirildi.
- Kompakt performans metrik şeridi ve Fon Kimliği bilgi şeridi eklendi.
- Genel Bakış, Performans, Risk, Portföy ve Geçmiş terminal sekmeleri eklendi.
- Veri yoğunluğu artırılırken mevcut Fonoloji/TEFAS veri akışı korunmuştur.

## V1.16.2 — Stable

- Fonoloji tabanlı fon araştırma altyapısının stabil temel sürümü.
