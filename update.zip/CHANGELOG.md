# Changelog

## V1.26.1 — Terminal Pro tam bileşen uyarlaması

- V1.26.0 sonrasında eski tasarım dilinde kalabilen bileşenler için kapsamlı ikinci geçiş yapıldı.
- Fon Ara, Portföy, İşlemler, Ayarlar, Model Analizi, boş/yükleniyor/hata durumları ve mobil navigasyon Terminal Pro diline uyarlandı.
- Eski mavi/yeşil buton, badge, segmented control, durum etiketi ve vurgu stilleri amber Terminal Pro sistemine taşındı.
- Dinamik Chart.js grafiklerindeki yaygın eski mavi/yeşil sabit renkler amber palete dönüştürüldü.
- Formlar, toggle/switch bileşenleri, toast, tooltip, modal ve durum kartları standardize edildi.
- Veri/Worker/model mantığı değiştirilmedi.



## V1.26.0 — Terminal Pro (D) Global Tema

- Seçilen `D — Terminal Pro (Kompakt)` tasarım dili uygulamanın tamamına uygulandı.
- Genel Bakış, Portföy, İşlemler, Fon Ara, Ayarlar ve Model Analizi aynı görsel sistemde birleştirildi.
- Siyah/füme zemin, amber-altın vurgu, ince terminal sınırları ve daha kompakt spacing kullanıldı.
- Kart, tablo, form, modal, sekme ve buton tasarımları tek standarda geçirildi.
- Finansal rakamlarda terminal hissi için monospaced tipografi güçlendirildi.
- Aktif sekme ve menülerde amber çizgi/vurgu kullanıldı.
- Pozitif metrikler D tasarımına uygun amber tonunda, negatif metrikler kırmızı tonunda gösterilir.
- Tablet ve mobil görünüm aynı tasarım dilini korurken dokunmatik kullanım rahatlığı korunur.
- İşlevsel veri akışı, Worker entegrasyonu ve Model Analizi mantığı değiştirilmedi.



## V1.25.2 — Fon Ara tarihsel veri fallback düzeltmesi

- Fon Ara performans grafiklerinde fonlar arasında oluşan tutarsızlık düzeltildi.
- Tarihsel NAV kaynağı artık sağlam fallback zinciri kullanır:
  1. Fonoloji `/history`
  2. Fonoloji `/timeseries`
  3. TEFAS geçmişi
- TTE gibi `/history` verisi eksik gelen fonlarda mevcut `/timeseries` serisi tekrar kullanılabilir.
- Drawdown için Fonoloji serisi varsa kullanılır, yoksa NAV geçmişinden hesaplanır.
- Aylık getiri için Fonoloji aylık seri varsa kullanılır, yoksa NAV geçmişinden türetilir.
- Gerçek tarihsel seri mevcut olduğunda performans bölümü yeniden çizgi grafik olarak gösterilir.
- Model Analizi kota-optimize endpoint'i değiştirilmedi.



## V1.25.1 — Fon Ara tarihsel grafik düzeltmesi

- Bazı fonlarda boş kalan 1 yıllık fiyat, Drawdown ve Rolling Volatilite grafikleri düzeltildi.
- Fon Ara tarihsel NAV kaynağı `/funds/:code/history?period=1y` endpoint'ine taşındı.
- Drawdown ile 30/90 günlük volatilite aynı NAV serisinden Worker tarafında hesaplanır.
- Aylık getiri serisi NAV geçmişinden türetilir.
- Tarihsel veri gerçekten yetersizse boş panel yerine açıklama gösterilir.
- Model Analizi kota-optimize endpoint'i değiştirilmedi.



## V1.25.0 — Fon Ara Model Analizi

- Sidebar `VARLIK ARAŞTIR` adı `FON ARA` olarak değiştirildi.
- Portföy sayfasındaki Fon Model Analizi kaldırıldı.
- Fon terminaline `MODEL ANALİZİ` sekmesi eklendi.
- Aratılan fonun analizi sekmeye girildiğinde otomatik çalışır.
- Kota optimize `/api/model/fund/:code` endpoint'i korunur.



## V1.24.3 — Model Analizi Fonoloji Kota Optimizasyonu

- Model Analizi artık genel `/api/research/fund/:code` endpoint'ini kullanmaz.
- Yeni `/api/model/fund/:code` endpoint'i yalnızca tek Fonoloji `/funds/:code` çağrısıyla model verisini hazırlar.
- Model analizi için timeseries, history, portfolio ve analysis endpoint çağrıları kaldırıldı.
- Model Worker yanıtı 6 saat cache'lenir; aynı fonun tekrar analizi normalde 0 yeni Fonoloji isteği tüketir.
- Fonoloji `/funds/:code` verisinin model amaçlı freshness süresi 6 saate çıkarıldı, 24 saat stale fallback korunur.
- Tarayıcı tarafındaki model cache'i 10 dakikadan 60 dakikaya çıkarıldı.
- İlk cache miss'te hedef tüketim: 1 Fonoloji isteği / fon.
- İki fonluk portföy için hedef: ilk analiz 2 istek, aynı fonlarda sonraki analizler cache süresince 0 istek.



## V1.24.2 — Model Analizi tıklama bağlantısı düzeltmesi

- `Analiz Et` butonu artık doğrudan HTML `onclick` üzerinden global güvenli analiz fonksiyonuna bağlıdır.
- Geç bağlanan event listener bağımlılığı kaldırıldı.
- Butona basıldığı anda `Analiz başlatılıyor…` mesajı gösterilir.
- Analiz arayüzü bulunamazsa veya çalışma sırasında hata oluşursa hata mesajı doğrudan panelde görünür.
- Portföyde fon bulunmaması durumunda buton kilitli kalmaz.
- Merkezi Worker araştırma endpoint'i doğrulandı: `/api/research/fund/:code`.



## V1.24.1 — Model Analizi buton düzeltmesi

- `Analiz Et` butonunun çalışmamasına neden olan API yapılandırma anahtarı hatası düzeltildi.
- Model motoru artık uygulamanın mevcut `requireApiBase()` bağlantısını kullanıyor.
- Portföydeki fon türü kayıtları için geriye dönük uyumlu fon algılama eklendi.
- Analiz butonuna güvenli hata yakalama eklendi; hata olursa ekranda açık mesaj gösterilir.
- Model analizinin mevcut merkezi Worker/API bağlantısı üzerinden çalışması sağlandı.



## V1.24.0 — Portföy Fon Model Analizi

- Yalnızca portföydeki yatırım fonları için Model Analizi eklendi.
- 100 puanlık şeffaf model: Trend & Momentum 35, Risk Düzeltilmiş Kalite 30, Göreli Güç 20, Fon Sağlığı 15.
- Sonuçlar AL / TUT / SAT / YETERSİZ VERİ model sinyali, güven seviyesi ve veri tamlığı ile gösterilir.
- Sinyal otomatik emir oluşturmaz ve yatırım tavsiyesi olarak sunulmaz.
- Analiz verileri mevcut Fonoloji araştırma hattından alınır; istemci tarafında 10 dakika önbelleğe alınır.
- Her fon için puan bileşenleri ve kısa gerekçeler görünür.



## V1.23.8 — Sidebar ikon/metin düzeltmesi

- V1.23.7'de menü metinlerini ikon kutusuna dönüştüren hatalı `first-child` CSS seçicileri tamamen kaldırıldı.
- Sidebar HTML yapısı gerçek yapıya göre yeniden düzenlendi: her menü öğesinde ayrı `nav-icon` ve `nav-label` alanı bulunur.
- Eski karakter ikonları kaldırıldı ve beş yeni SVG terminal ikonu doğrudan menü öğelerine yerleştirildi.
- Menü metinleri büyük harf olarak korunur.
- Masaüstünde ikon + metin, mobil/tablette yalnızca ikon gösterilir.
- İkon ve metin stilleri artık birbirini etkileyemez.


## V1.23.7 — Terminal sidebar ikon seti

- Sidebar ikonları tek bir modern terminal/finans tasarım dilinde yeniden çizildi.
- Genel Bakış: modern ana ekran simgesi.
- Portföy: varlık dağılımı/pasta grafik simgesi.
- İşlemler: çift yönlü işlem okları.
- Varlık Araştır: büyüteç içinde piyasa hareketi.
- Ayarlar: altıgen terminal çekirdeği.
- Tüm menü başlıkları büyük harfe çevrildi.
- İkon ölçüleri, stroke kalınlıkları ve hizalamaları eşitlendi.


## V1.23.6 — Genel Bakış yan yana panel düzeltmesi

- En Büyük Pozisyonlar ve Varlık Dağılımı yeniden aynı satıra alındı.
- Önceki `grid-column: span 7 / span 5` hatası kaldırıldı.
- En Büyük Pozisyonlar solda geniş, Varlık Dağılımı sağda dar olacak şekilde doğrudan parent grid oranlandı.
- Tablet/iPad görünümünde yan yana kalır; yalnızca telefon genişliğinde alt alta geçer.
- Donut grafik dar karta göre yeniden ölçeklendirildi.


## V1.23.5 — Genel Bakış Panel Yerleşimi

- `En Büyük Pozisyonlar` ve `Varlık Dağılımı` panellerinin yerleri değiştirildi.
- `En Büyük Pozisyonlar` solda ve daha geniş olacak şekilde oranlı büyütüldü.
- `Varlık Dağılımı` sağda ve daha dar olacak şekilde oranlı küçültüldü.
- Geniş ekranlarda yaklaşık 1.65 / 0.95 oranlı iki kolon kullanılır.
- Dar ekranlarda paneller tek sütunda alt alta geçer.
- Sürüm/cache V1.23.5 olarak güncellendi.


## V1.23.4 — 1 Haftalık Portföy Analizi

- Genel Bakış > Portföy Analizi tarih seçeneklerine `1H` eklendi.
- `1H`, portföy geçmişindeki en güncel kayıttan son 7 günü filtreler.
- Portföy Gelişimi ve Kâr / Zarar Gelişimi grafikleri seçilen 1 haftalık aralığa birlikte uyum sağlar.
- Sürüm/cache V1.23.4 olarak güncellendi.


## V1.23.3 — Fon Arama Stack Hatası Düzeltmesi

- `requireApiBase()` fonksiyonunun yanlışlıkla kendi kendini çağırması düzeltildi; artık `getApiBase()` kullanır.
- `Maximum call stack size exceeded` hatasının kök nedeni giderildi.
- Merkezi production Worker adresi `index.html` içine de gömüldü.
- Mevcut ZIP updater `config.js` dosyasını kopyalamasa bile uygulama merkezi Worker'a otomatik bağlanır.
- Worker adresi: `https://portfoyum-api.haydarcicek94.workers.dev`
- Sürüm/cache V1.23.3 olarak güncellendi.


## V1.23.2 — Cloudflare Deploy Tarih Düzeltmesi

- Cloudflare build hatasına neden olan `compatibility_date = "2026-08-17"` değeri `2026-08-16` olarak düzeltildi.
- GitHub → Cloudflare otomatik Worker deploy akışı için mevcut Wrangler yapılandırması korunur.
- Rate limit binding ve diğer Worker ayarları değiştirilmedi.
- Sürüm/cache V1.23.2 olarak güncellendi.


## V1.23.1 — Merkezi Worker Bağlantısı

- Production Worker adresi `config.js` içine tanımlandı.
- Son kullanıcı artık Worker adresi veya API anahtarı girmeden uygulamayı kullanabilir.
- Merkezi backend: `portfoyum-api.haydarcicek94.workers.dev`
- Sürüm/cache V1.23.1 olarak güncellendi.


## V1.23.0 — Ortak Production Backend

- Son kullanıcıdan Worker URL isteme kaldırıldı; API adresi `config.js` üzerinden tek seferlik uygulama sahibi ayarına taşındı.
- Ayarlar ekranındaki Worker URL ve bağlantı testi kaldırıldı.
- Tarayıcıya anonim kalıcı client ID ve `X-Portfoyum-Client` başlığı eklendi.
- Worker'a yüksek trafikli araştırma endpoint'leri için response cache eklendi.
- Fonoloji cache yapısına stale fallback eklendi.
- Cloudflare Rate Limiting binding ve opsiyonel `ALLOWED_ORIGINS` desteği eklendi.
- `FONOLOJI_KEY` required secret olarak tanımlandı.
- Sürüm/cache V1.23.0 olarak güncellendi.


## V1.22.4 — Uygulama İkonu

- Seçilen Portföyüm Terminal ikonu uygulamanın gerçek favicon / app icon setine eklendi.
- 32, 48, 180, 192 ve 512 px ikon varyantları oluşturuldu.
- Safari / iOS için Apple Touch Icon eklendi.
- Favicon ve web manifest bağlantıları index.html'e tanımlandı.
- Uygulamanın işlevsel koduna dokunulmadı.
- Sürüm/cache V1.22.4 olarak güncellendi.


## V1.22.3 — Mobil Alt Menü Düzeltmesi

- Mobil/tablet alt navigasyon tekrar görünür hale getirildi.
- 900 px ve altındaki ekranlarda sidebar zorunlu olarak sabit alt bar olarak gösterilir.
- Eski research/sidebar kurallarının alt menüyü gizlemesi `display`, `visibility`, `opacity` ve `z-index` seviyesinde engellendi.
- Menü içerik tarafından örtülmesin diye ana içerik alt boşluğu artırıldı.
- Masaüstü sol sidebar davranışı korunur.
- Sürüm/cache V1.22.3 olarak güncellendi.


## V1.22.2 — Geçmiş Grafiklerinin Kesin Sekme Düzeltmesi

- Asıl hata tespit edildi: eski `#researchSecondarySections { display:grid !important; }` kuralı, `hidden` durumunu CSS özgüllüğü nedeniyle eziyordu.
- Çakışan `display:grid !important` doğrudan eski kuraldan kaldırıldı.
- Geçmiş kapsayıcısı yalnızca görünür ve Geçmiş sekmesi aktif olduğunda `display:grid` alır.
- `Fon Büyüklüğü Geçmişi` ve `Yatırımcı Sayısı Geçmişi` artık Genel Bakış, Performans ve Portföy sekmelerinde CSS seviyesinde görünemez.
- Sürüm/cache V1.22.2 olarak güncellendi.


## V1.22.1 — Geçmiş Sekmesi İzolasyonu

- `Fon Büyüklüğü Geçmişi` ve `Yatırımcı Sayısı Geçmişi` yalnızca Geçmiş sekmesine bağlandı.
- History kapsayıcısı HTML'de varsayılan olarak `hidden` başlar.
- Sekme değişiminde hem `hidden` niteliği hem `terminal-tab-hidden` sınıfı yönetilir.
- Asenkron Fonoloji verisi yüklendiğinde aktif sekme yeniden kontrol edilir; grafikler diğer sekmelerde açılmaz.
- Sürüm/cache V1.22.1 olarak güncellendi.


## V1.22.0 — Genel Sekmesi Temizliği

- Genel sekmesinde görünen `Fon Büyüklüğü Geçmişi` ve `Yatırımcı Sayısı Geçmişi` blokları kaldırıldı.
- Bu iki grafik silinmedi; yalnızca `Geçmiş` sekmesinde gösterilmeye devam eder.
- Sekme görünürlüğü JS + CSS seviyesinde sıkılaştırıldı; asenkron veri yüklenince Genel sekmesine tekrar sızmaları engellendi.
- Sürüm/cache V1.22.0 olarak güncellendi.


## V1.21.9 — Tek Tema Modu

- Sidebar'daki Koyu / Açık tema seçici kaldırıldı.
- Ayarlar ekranındaki Tema kartı ve Tema Değiştir butonu kaldırıldı.
- Uygulama koyu terminal temasına sabitlendi.
- Önceden localStorage'a kaydedilmiş tema tercihi yüklemede temizlenir.
- API ve diğer kullanıcı ayarları korunur.
- Sürüm/cache V1.21.9 olarak senkronlandı.


## V1.21.8 — Sidebar Tek Kaynak Düzeltmesi

- Varlık Araştır'a özel logo, marka yazısı, menü ve sidebar-alt stilleri kaynak CSS'ten kaldırıldı.
- Genel Bakış ve Varlık Araştır artık aynı `.terminal-app-mode` sidebar/brand/nav stillerini birebir paylaşır.
- Araştırma modunda yalnızca sidebar konumu ve içerik scroll geometrisi ayrı tutulur; görsel ölçülere müdahale edilmez.
- Önceki sahte logo `::before`, farklı font-size, nav margin ve footer spacing kalıntıları temizlendi.
- Sürüm/cache V1.21.8 olarak senkronlandı.


## V1.21.7 — Varlık Araştır Sidebar/Logo Kesin Eşitleme

- Varlık Araştır'daki eski `nav margin-top: 28px` etkisi tamamen sıfırlandı.
- Araştırma ekranında logoyu değiştiren `font-size: 0` + sahte `::before P` yöntemi devre dışı bırakıldı.
- Logo kutusu, PORTFÖYÜM / TERMINAL tipografisi, menü satırları ve sidebar alt alanı Genel Bakış ile aynı ölçülere sabitlendi.
- Sidebar footer aralığı Genel Bakış'taki 10 px düzene getirildi.
- Araştırma içerik scroll sistemi korunurken sol navigasyon artık sekme değişiminde hareket etmez.
- Mobil sabit alt bar davranışı korunur.
- Sürüm/cache V1.21.7 olarak senkronlandı.


## V1.21.6 — Varlık Araştır Hizalama Düzeltmesi

- Varlık Araştır ekranındaki sidebar ve içerik başlangıcı Genel Bakış ile aynı 240 px koordinat sistemine sabitlendi.
- Eski 210/230 px research kurallarının masaüstü/tablet görünümünde yeniden devreye girmesi engellendi.
- Logo, menü satırları, tema alanı ve ana içerik yatay konumu sekme değişiminde artık kaymaz.
- Mobil alt bar davranışı V1.21.5'teki haliyle korundu.
- Sürüm/cache V1.21.6 olarak senkronlandı.


## V1.21.5 — Mobil / Tablet Navigasyon Düzeltmesi

- Varlık Araştır ekranındaki eski mobil `position: relative` sidebar kuralı final override ile etkisizleştirildi.
- Telefon ve tablette Varlık Araştır artık Genel Bakış ile aynı sabit alt navigasyonu kullanır.
- Mobil/tablet alt barda yalnızca 5 ana menü ikonu gösterilir.
- Logo, tema seçici, Fonoloji açıklaması ve sürüm bilgisi mobil sidebar içinde gizlenir.
- Masaüstü sol sidebar davranışı değiştirilmedi.
- Sürüm/cache V1.21.5 olarak senkronlandı.


## V1.21.4 — Geçmiş Grafik Gerçek Genişlik Düzeltmesi

- Grafiklerin küçük kalmasına neden olan dış `researchSecondarySections` iki sütunlu grid yapısı düzeltildi.
- Geçmiş sekmesinin dış kapsayıcısı artık tek tam genişlik sütun kullanır.
- Fon Büyüklüğü Geçmişi ve Yatırımcı Sayısı Geçmişi bu tam alanın içinde eşit %50 / %50 paylaşılır.
- Grafik yüksekliği 355 px'e çıkarıldı ve canvas kart genişliğine zorlandı.
- Dar ekranlarda tek sütun davranışı korunuyor.
- Sürüm/cache V1.21.4 olarak senkronlandı.


## V1.21.3 — Varlık Araştır Ölçek Düzeltmesi

- Varlık Araştır ekranındaki özel sidebar boyutlandırmaları kaldırılarak Genel Bakış ile aynı ölçülere getirildi.
- Logo, PORTFÖYÜM/TERMINAL yazıları, menü satırları, ikonlar ve sidebar genişliği sekmeler arasında artık değişmez.
- Araştırma ekranının scroll düzeltmesi korunurken içerik başlangıcı 240 px global sidebar ölçüsüne bağlandı.
- Tablet yatay görünümündeki 210 px özel araştırma sidebar kuralı kaldırıldı.
- Sürüm/cache V1.21.3 olarak senkronlandı.


## V1.21.2 — Terminal Renk Temizliği

- Eski tasarımdan kalan dekoratif yeşil/sage tonları uygulama genelinde temizlendi.
- Portföy filtreleri, günlük getiri şeritleri, varlık/pozisyon ikonları ve eski accent alanları terminal mavi-grafit paletine geçirildi.
- Genel Bakış varlık dağılımı grafiği mavi/cyan/mor terminal paletine geçirildi.
- Eski CSS değişkenleri koyu terminal sistemiyle senkronlandı; gözden kaçmış eski bileşenler de yeni paleti kullanır.
- Gerçek kazanç/kayıp anlamındaki yeşil ve kırmızı renkler semantik olarak korundu.
- Sürüm/cache V1.21.2 olarak senkronlandı.


## V1.21.1 — Geçmiş Grafik Yerleşimi

- Fon Büyüklüğü Geçmişi ve Yatırımcı Sayısı Geçmişi kartları mevcut alanı eşit şekilde dolduracak biçimde genişletildi.
- Grafik yüksekliği artırıldı; tarih ve eksen etiketlerinin sıkışması azaltıldı.
- Tablet/dar ekranlarda grafikler otomatik olarak tek sütuna geçecek şekilde düzenlendi.
- Sürüm/cache V1.21.1 olarak senkronlandı.


## V1.21.0 — Global Terminal Tasarım Sistemi

- Varlık Araştır ekranındaki terminal tasarım dili tüm uygulamaya yayıldı.
- Genel Bakış, Portföy, İşlemler ve Ayarlar ekranları koyu terminal paletine geçirildi.
- Kartlar, tablolar, butonlar, formlar, grafik panelleri ve metrikler ortak terminal bileşen sistemine bağlandı.
- Sayısal verilerde monospace/tabular görünüm ve daha sıkı veri yoğunluğu uygulandı.
- Mevcut hesaplama, portföy, işlem ve veri akışı korunarak yalnızca arayüz katmanı yenilendi.
- Sürüm/cache V1.21.0 olarak senkronlandı.


## V1.20.7 — Geçmiş Sekmesi Düzeltmesi

- Geçmiş sekmesindeki `Fon Büyüklüğü`, `Fon Profili` ve `Ücret ve Giderler` kartları kaldırıldı.
- `Fon Büyüklüğü Geçmişi` grafiği Geçmiş sekmesine geri eklendi.
- `Yatırımcı Sayısı Geçmişi` grafiği Geçmiş sekmesine geri eklendi.
- Genel Bakış'taki AUM grafiği ve Portföy sekmesindeki diğer Fonoloji detayları korunuyor.
- Sürüm/cache V1.20.7 olarak senkronlandı.


## V1.20.6 — Geçmiş Sadeleştirmesi

- Geçmiş bölümündeki `Fon Büyüklüğü Geçmişi` grafiği kaldırıldı.
- Geçmiş bölümündeki `Yatırımcı Sayısı Geçmişi` grafiği kaldırıldı.
- Fonoloji verisinin diğer kullanımları korunarak yalnızca bu iki tekrar eden görsel bileşen temizlendi.
- Sürüm/cache V1.20.6 olarak senkronlandı.


## V1.20.5 — Tekrar Eden Alanlar

- Terminal navigasyonundaki gereksiz Risk sekmesi kaldırıldı.
- Fonoloji detaylarında Genel Bakış'taki veriyi tekrar eden ikinci Aylık Getiri Haritası kaldırıldı.
- Genel Bakış'taki ana aylık getiri görünümü korunuyor.
- Sürüm/cache V1.20.5 olarak senkronlandı.


## V1.20.4 — Araştırma Ekranı Sadeleştirmesi

- Boş ve tekrarlayan `Risk` sekmesi kaldırıldı.
- Genel görünümde tekrar eden `Aylık Getiri Haritası` kartı kaldırıldı.
- Portföy dağılımı bölümü korunarak kullanılabilir alan sadeleştirildi.
- Sürüm/cache V1.20.4 olarak senkronlandı.


## V1.20.3 — Fon Arama Hatası Düzeltmesi

- `Maximum call stack size exceeded` hatasına neden olan scroll helper özyinelemesi giderildi.
- `resetResearchScroll()` artık yalnızca gerçek scroll alanlarını sıfırlar ve kendini tekrar çağırmaz.
- Fon arama akışı ve araştırma ekranı yeniden çalışır hale getirildi.
- Sürüm ve cache değerleri V1.20.3 olarak senkronlandı.


## V1.20.2 — Araştırma Viewport Düzeltmesi

- Araştırma ekranının aşağı itilmesine neden olan eski document-scroll / sabit sidebar çakışması giderildi.
- Varlık Araştır açıkken ana içerik alanı viewport'a sabitlendi ve kendi scroll alanına dönüştürüldü.
- Araştırma ekranına her girişte hem içerik scroller'ı hem document scroll konumu sıfırlanır.
- Sürüm ve cache değerleri V1.20.2 olarak senkronlandı.


## V1.20.1 — Araştırma Yerleşim Düzeltmesi

- Varlık Araştır ekranına geçildiğinde scroll konumu otomatik olarak en üste sıfırlanır.
- Önceki ekrandan taşınan scroll konumunun oluşturduğu büyük üst boşluk giderildi.
- Yinelenen üst hızlı arama alanı kaldırıldı; yalnızca sağdaki fon türü + kod + Araştır formu bırakıldı.
- Görünen sürüm ve cache sürümleri V1.20.1 olarak senkronlandı.


## V1.19.0 — Reference-Matched Terminal UI

- Fon araştırma ekranı seçilen referans tasarıma göre baştan düzenlendi.
- Sol terminal menüsü, canlı veri başlığı, kompakt arama alanı ve fon bilgi kartı eklendi.
- Dönemsel getiri şeridi ve terminal sekmeleri referans hiyerarşisine taşındı.
- Ana görünümde çizgi performans grafiği, yoğun risk tablosu, aylık getiri matrisi ve AUM grafiği bir araya getirildi.
- Fonoloji / TEFAS veri akışı ve Worker altyapısı değiştirilmedi.


## V1.18.0 — Terminal UI Refinement

- Fon kimliği ve temel bilgiler üst terminal kartında birleştirildi.
- Tekrarlayan ayrı kimlik şeridi kaldırıldı.
- Fon performans grafiği kümülatif çizgi grafik olarak yenilendi.
- 1A / 3A / 6A / 1Y dönem seçimi eklendi.
- Risk metrikleri daha yoğun terminal tablosuna dönüştürüldü.
- Koyu tema, ikinci terminal tasarım hedefi doğrultusunda yeniden düzenlendi.


Portföyüm uygulamasındaki önemli değişiklikler burada tutulur.

## V1.17.0 — Portföyüm Terminal

- Fon araştırma ekranı profesyonel terminal tasarım diline geçirildi.
- Kompakt performans metrik şeridi ve Fon Kimliği bilgi şeridi eklendi.
- Genel Bakış, Performans, Risk, Portföy ve Geçmiş terminal sekmeleri eklendi.
- Veri yoğunluğu artırılırken mevcut Fonoloji/TEFAS veri akışı korunmuştur.

## V1.16.2 — Stable

- Fonoloji tabanlı fon araştırma altyapısının stabil temel sürümü.
